import pandas as pd
from utils import load_data, get_questions_by_category, check_answer

def ask_question(question):
    """Ask a question and get the user's answer."""
    print(question)
    return input("Your answer: ").strip()

def evaluate_performance(correct_answers_count, total_questions):
    """Calculate the performance percentage."""
    return (correct_answers_count / total_questions) * 100

def main():
    questions_df, answers_df = load_data()
    answers_dict = answers_df.set_index('id').to_dict()['answer']
    categories = questions_df['category'].unique()
    
    print("Welcome to the Programming and Computer Science Quiz!")
    print(f"Available categories: {', '.join(categories)}")
    
    while True:
        category = input("Select a category (Programming, Computer Science) or type 'exit' to quit: ").strip()
        if category.lower() == 'exit':
            print("Goodbye!")
            break
        
        if category not in categories:
            print("Invalid category. Please try again.")
            continue
        
        questions = get_questions_by_category(questions_df, category)
        correct_answers_count = 0
        
        for _, row in questions.iterrows():
            q_id = row['id']
            question = row['question']
            user_answer = ask_question(question)
            if check_answer(q_id, user_answer, answers_dict):
                print("Correct!")
                correct_answers_count += 1
            else:
                print(f"Incorrect. The correct answer is: {answers_dict[q_id]}")
        
        performance = evaluate_performance(correct_answers_count, len(questions))
        print(f"Your performance in {category}: {performance:.2f}%")
        
if __name__ == "__main__":
    main()
