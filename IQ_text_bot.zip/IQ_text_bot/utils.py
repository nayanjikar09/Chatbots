import pandas as pd

def load_data():
    questions_df = pd.read_csv('data/questions.csv')
    answers_df = pd.read_csv('data/answers.csv')
    return questions_df, answers_df

def get_questions_by_category(questions_df, category):
    """Get questions for a specific category."""
    return questions_df[questions_df['category'] == category]

def check_answer(q_id, user_answer, answers_dict):
    """Check if the user's answer is correct."""
    correct_answer = answers_dict[q_id]
    return user_answer.lower() == correct_answer.lower()
