# Medico Care Chat-Bot
a chatbot based on sklearn where you can give a symptom.
hence it will ask you questions and will tell you the details and give some advice.
I have in total listed 41 diseases with a master data file with Symptom Description, 
Symptom Precautions measures to be undertaken and severity of any condition.